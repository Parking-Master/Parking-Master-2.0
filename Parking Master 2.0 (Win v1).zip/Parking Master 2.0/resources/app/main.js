const { BrowserWindow, app, Menu, shell, dialog, nativeTheme } = require("electron");
const https = require('https');

app.setName("Parking Master 2.0");

app.on("ready", function() {
  const mainWindow = new BrowserWindow({
    show: false,
    hasShadow: false,
    titleBarStyle: "hidden",
    frame: false,
    roundedCorners: false,
    icon: __dirname + "/favicon.ico",
    title: "Parking Master 2.0"
  });
  nativeTheme.themeSource = "system";
  mainWindow.loadFile("blank");
  function renderProcessExecutions(process_window, handler, callback) {
    process_window.webContents.on("console-message", function(r, e, i) {
      if (i.split("[")[0] == ("#Electron:" + handler.trim() + " ")) {
        callback(i.split("[")[1].split("").reverse().splice(1).reverse().join(""));
      }
    });
  }
  mainWindow.webContents.executeJavaScript(`
  function showUpdate(information = "No information about this update") {
    setTimeout(() => {
      if (confirm("(Parking Master 2.0)\\n\\nA new update is available. Do you want to install it?") == true) {
        console.log("#Electron:update_proceed [true]");
        simple.alert("Please wait for the update to complete.\\n\\n" + decodeURIComponent(information));
        document.querySelector(".swal-footer").innerHTML = \`
        <style>
        .progress {
          width: 100%;
          background-color: #fff;
          height: 20px;
        }
        .progress_bar {
          width: 1%;
          height: 20px;
          background-color: #333;
        }
        </style>
        <div class="progress">
          <div class="progress_bar"></div>
        </div>
        \`;
        !function(){let e=0;if(0==e){e=1;let t=1,r=setInterval((function(){t>=100?(clearInterval(r),e=0):(t+=.1,document.querySelector(".progress_bar").style.width=t+"%")}),1)}}();
      }
    }, 2000);
  }
  `)
  renderProcessExecutions(mainWindow, "dialog_box", (msg) => {
    const dialog = new BrowserWindow({
      frame: false,
      hasShadow: false,
      title: "Warning",
      titleBarStyle: "hidden",
      backgroundColor: "#fff",
      width: 400,
      height: 250,
      alwaysOnTop: true,
      parent: mainWindow,
      closable: false,
      minimizable: false,
      maximizable: false,
      movable: false,
      show: false
    });
    dialog.loadFile("blank");
    dialog.webContents.executeJavaScript(`document.body.style = "margin: 0; padding: -2px; border-radius: 10px; position: absolute; border: 2px solid #ddd; width: 99%; height: 98.4%;"; document.body.innerHTML += \`
    <h1 style="font-family:Arial,Helvetica,sans-serif;text-align:center;color:#ddd;">Warning</h1>
    \`;`);
    dialog.webContents.executeJavaScript(`document.body.innerHTML += \`
    <br>
    <p style="font-family:Arial,Helvetica,sans-serif;text-align:center;color:#ddd;">${decodeURIComponent(msg)}</p>
    \`;`);
    dialog.webContents.executeJavaScript(`document.body.innerHTML += \`
    <br>
    <button style="cursor:pointer;position:relative;left:32.5%;background:#ddd;color:#fff;border:none;outline:none;padding:4px 5px;border-radius:3px;margin:5px;align:right;" align="right" onclick="window.close()">Cancel</button>
    <button style="cursor:pointer;position:relative;left:32.5%;background:#ddd;color:#fff;border:none;outline:none;padding:4px 5px;border-radius:3px;margin:5px;align:right;" align="right" onclick="console.log('#Electron:close_all_windows []')">Confirm</button>
    \`;`);
    renderProcessExecutions(dialog, "close_all_windows", () => {
      let opac = 1;
      setInterval(function() {
        if (opac > 0) {
          opac += -.1;
          mainWindow.setOpacity(opac);
          dialog.setOpacity(opac);
        } else {
          app.quit();
          dialog.blur();
          mainWindow.blur();
          dialog.close();
          mainWindow.close();
        }
      }, 3.5);
    });
    dialog.show();
  });
  mainWindow.webContents.executeJavaScript("!window.navigator.onLine && console.log('#Electron:offline_network_report []')");
  mainWindow.loadURL("https://parkingmaster.tk/index.html");
  renderProcessExecutions(mainWindow, "offline_network_report", () => {
    mainWindow.loadFile("err/offline/index.html");
  });
  mainWindow.maximize();
  mainWindow.resizable = false;
  mainWindow.show();
  mainWindow.webContents.on("did-finish-load", () => {
    mainWindow.webContents.executeJavaScript("document.querySelector('body').innerHTML += `<div style='user-select:none!important;font-size:10px;fill:#ddd;color:#ddd;position:absolute;left:0;top:0;padding:10px!important;height:20px!important;left:50%;width:15%;margin-left:-7.5%!important;margin:0;background:#fff;box-shadow:0 0 10px 3px #ddd;z-index:9999!important;' id='window_options'><img onclick='history.go(-1)' style='cursor:pointer;margin-left:2px;top:3px;position:absolute;width:35px;left:0%;margin-left:0px;' src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAVoAAAFVAQMAAACUybXgAAAABlBMVEXg4OD///9NNgK4AAAHAElEQVRo3tXbP7PcNBAAcDnH42DC4IIidDcDBR0pU14+Ah3lY4ahp6SzCr4HKSnzDVBJmQ4q4oaZV1C4gIzmYWRylmxrV7sryRcyw3XJ+40trWRZf9ZqKv8Z9XaxUqorxE5dfqcyrPzvXIL7gJsCPKrld8pjs2KVxW6zyaUT3Ee4yWEV/84ytgC3MjYANzJW8PdYwhbhVsI9wo2ENcKw80E8YgvbBeIhwUcemwQ3PFbpr+PwSOAThwcCHzncE7jhsFZyoWPsKBt30xiPJG5pPJC4obGJy5nDGjzVOq1hhB2skktrGOGlfgdUhZbCFt82acMI9/DC66UbChvccxwexSKcDnAGlWvDLu1lFt1rwyMxYqFwbNgSw6yBN9twnz6gIR6HFBtiSHbwbhvW6aCC/3PD5PDdg0qv2BFFXmp9wtiSbxEHYrfigSpyKPQR4557T0axW7Ghihxu2GCsiRfO2gk6hJl3O5ghLNjR9Qt3RHik6xcqfoTYwicK1RDhga4fvMqCe2am4yuDsGHq58PUQKypych2GYi5YIQCdgk+knjYWitgxwUjhOMU45ELBrhOwJbuGaiEAQ9s5HygDjHu2WD42AFsmJ4BLxThI4OHtVXM9rZpGWzX+gTMRy7E7rxhJ0TOXwnjjsN6ua3HI9vnltq3G7ZCmKNQeTwIYfaBRvjI4vVSHvdCmKNCemyEMPvqF2O3xMpjLbWJb5VuxWKb+GtBLK7W/I1n7MQ22ao041FsEx/ZYjyEZpixFRvQ/x3gVsBjuNiMB7FNtmIWYRfjXm7AuR2aBRu5AVMsLri1BzPWOWwgbkTc+3LOONOAlXjw4bpgl2ntSmx9q13wmOkaXkT4lMWtxzaLHcTnLD56PGTxBHE35TrHweMeY3IuGGEYVWIb5NJ7Am5ge7U8Ngj3aXv2MT7AyxyobuexRlinvXuI8REFlcIdhR2B7YpRDx1zuE3+kHa7M4UHCTvUQ/saTI1P3gR8Jl43JB4RJl9dDHYcbhfcofUDi1FcLflS1BEmZ2YIHwncc8umGQ/p+lnEDTlPRfhAYHqO3gcMn1dmjh7hAwrzqRAzc/S5rAlm5ugLNqBCPT2roTEdZgbTYfbNnGBmKRThNhfmFev4r9xSaKQwtxSanxCMuaVQhE+5MNOYCfNc8QsGNWLCTGNuxRnhcy7MfthCeJSW3xjzK04CD9Ja/TUGg2jPztEJbNg5+oa7XJj9mIswv7BPsbCw1wkWFvYpFhb2KRYW9h7Hbwk+zBHOh5nAfJgJLGxVJ9gJW+YJlg4FLkMRwFY4FEgwtcN+4HB/LW44bK7FisP67eLuf4jfSDTMtbh5Ix2pqotWdf6qx6rqgc0MBe3+QaZu+CoaGIuH3KrBfPdrouoFVPVqq3pp1r2OS170+6YQucnJ/mlP1YSqZKpWNgk8XzW9zE1ca6fEVZPtndP4qgVCbukB1ikFi5q9yyUm0HbPEq9q8XjFspRf8DbVS+mqRXrt8r98Y6Fqy6J6M6Rkm4XCI3c6Te325LeGSjadSKxze19VG2W5LTiAizf3rto2lDckq7Y6azdRy7dnqzZ+y7aU1Y7N6tptcAXbVthgr9q6L8DboUD+uAHh4oOMqiOSssOXdjvWaUuPdarOgKqOosoOuc57js+KDua6PUd+2cNEHR0mVh1T5rDbfVpadWhbchy84jGDwUFz1RF27nAc4Kpj97oDfS1jleCz2CZREkI+vSHCcuIEyoWQUzIsTMmQkz0GmOwhp5GgzJBRDDRKUBlrUl+clIGzpefsSNcRVpihjLcR1rkUo58ibIROOs8KO3TlRqgfSF6SEq4UzqG6WytB4ya58pEPBsj7svxSfkwyyu4V2+9+TRLbhJQ5TWfB0eF4mubXaS4co14bEOLHzDOF0/x6MY/xAYHZDMkbiP9UTFea6/cQ4pH7viNODYU4HcL+5lNAW7qxl4vAtNWbBN+R+Bkdjq/IHNcXdF6uJrNn/WbkE4R9RG8w9puR71P9U32EsVNUx3tKpweHLcOXRJdLE4/Dru+nAN8rJv9Zs2nYRGa1IQo9B3/poGmCN2jxUIqHKX6VZrD/7P/nUYpD7JoTamtwEgd7bnTT0HzL0zpRKfo364WeKzaRPnQlpT4L//4r/Pvdib/yetvvFC5XhO8X/F7UO7lvELat6i9f/+u3ddP/lsLrpdSDb77+RBPfRsUfWbwgP9+gP7Ko+9aDxo9o7MiDjFsah4eo8DOZZzX4jxps5a9k8l8YvWTxc/aghsC25quoSSwywq7m46zpx5pvxCzfMVKMy/GDhHGf7kR8B+yTScT/xN20uZXx9H2EP5gyOD7K+yWLv13tO10WWybIJJ4+5D6mJL8A/YL5TJPEw6WHNIepCE+vPv/499upEPPLiv8M/wt628fFg4mLPgAAAABJRU5ErkJggg==' /><div id='WINDOW_OPTIONS_CLOSE' data-warn='" + (mainWindow.webContents.getURL().includes("play") || mainWindow.webContents.getURL().includes("multiplayer") ? "true" : "false") + "' style='cursor:pointer;text-align:center;font-size:45px;margin:0;top:-7.5px;position:absolute;left:50%;width:10%;margin-left:-5%;' onclick='window.close()'>&times;</div><img onclick='history.go(1)' style='cursor:pointer;margin-left:-2px;top:3px;position:absolute;width:35px;left:100%;margin-left:-35px;' src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAVoAAAFVAQMAAACUybXgAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAAGUExURd/f3////zMjcGAAAAcBSURBVGje1Zu9jiQ1EMfd1+wN0gl1SHCgvhCJiIhwTuIBEC8Aj8AjtMMLeYRL7ynWASIiuJDQAcGFBl3QLH1udvrLrnJV2d5ZncRks/1bj/2vctuuKqu5/GPUR4X9m9++fF4IuxdKqZvvimCvls+T2xLYrLD64pyH79T+OeXhVwfc3ubgO3PAasjBvwdWfTrIsH8dwepnGf43ZtWNDGsAPxFh/xLAqpfgO8giqRFsEXwz8LBX+NPz8JTAZx4eE/jEwyaB24GDfQqDfgA47TLsB4AtAX9WAzdDBaxuadhrCv6Jhu8oVrU0bGtgshexT8dwMMkP37z5heh0BIfx/XgZwPGto+AJNvXr/vVzCn6/G3hTdp9hDQX/sT38evv+TzLCCNbYKb8SWt5+9lnSr4GAt3aCL/gXaB4GeDP2J+nEeZ7C77FQh5hNCr9N3PcYcwob7DZhtg8JrJNezPNfDLy9jL6H70kDZvgBT8kkCj/XY/jv5c9P0aLxJxjIAb9D5osXggbDDs/OaCRPMGyRrcGfBwRTC87Ru5mCuwSeYjl2eO3ct+m2IW5khydy/d0bQfB7yiSHyzyD8Ds4gbAcEH6bulykP4INuRu5/3yIBrPDL1OXi99TENbM+LYnPYAZ5fYRnhP4KblNdGECbfBEG/t4dIrhkYfHIOoG22RRh3LcxLDj4UUO0LIRYHsItcGvGc84Gopbfsl4xjHCqOVlEJ0En6OW020Z8v8I9sL41oc9ggfuXHD0cYWn+C2cg0dBuVXoE4RbFnb70xV2zJwK2kWwFWReR9QE2Iiw34cf4J4/U+3CrrAWbLI9hvAgw+cDFm2y9vKAvWiTVay+FHabWAs8iQZcrXLAo2jA8PyAOwGeYtjJNlnG1JbC8ybAAlvZgCk8SLBejWbUZqFhzphwh7Vs7aO1HW5E2EawysFuVWCH21LYZ6y9mrgvhacATxnXOIgy2EO4z8KnFR5zrrHoVQ7rRdwL7HKukYU1OkRfbHyBLeFHHp+LJXiCDmAP2BB+NMI/re1xsIM/5mK4JTx4QPCwwJqADZR+jGEiZAQ8IAt3yO3OC0w5HWogC7eJ99/DnvJQNOF9DlZV8AAdurvAE+XOeLHLwj38fsADu8eIpbyHRwo26F2ShVv4/YDJ92ZTAysItxfYUbBD+zEb4EbYJhbAE9pDLjP2HrYU7NFW3QW4pbc6p1JYQ6Fl2EChF31X+DTnhN5hQ8JIaBlGQk8ijIRe/HiFuzkn9A5req2CQmdgKHQGhkL7APdzTugLfOZhKPQOM+srFDoDI6FlGAkd4POcFToDQ6Evvy/AUOgMDIXWC+w5GAqdgaHQAR7mrNAZGAqdgaHQORgInYOB0Bevl2AL44sy7GDIEMOWTwqscLyyEYHtPoHZDEkQOoFHId2QwE4IxhfBDQfba2HFweZqeHgMWP8PYfNx4Ucxd5UjuWvh9lGmVX7C+ppXQdVL5sGvrytejFWv3KqXec0yUbUAcUtb1aJZvBwXLvSPuYVINicP2fZUbajKt2q6ZhNYtb0s3rg+ZEt89Wab3sZXHRCKjx7Fh5oHHZfoUxtzEKs94l17eGSOpa7mwFt1lK49pJcf/6sCC9Uhi+JgyFQTZmGjPR0T7cmGhvY4kq8JOpWGs+oDZVy8rqmB2+vDhgUByTEHs6HO8iBqVXi2KvBra0LKVcHqqjA4HWA/p9avDt2XZRAiuC9NN1QlMqpSJL4m+VKVA8pnl6rgOG+la5JcVekzU5OYq0r5ZTOPugaO05TV2dKuFK5K2k416eBcohlkpatS2D6TSQfJ8aq0e11CP1MqAOsK5CIEVLFga8obrGgVVDjhRKugkgy5MsSlsBJtEpWRyAUqBhao5Etf+gDPUlHNrAi4l2Q+R7AWhJ5wPZLJlRjNEWwFoR2GnaBdaCiGhzlzsI/rvs5z5mAfV5T1c+Zgv8FesdpNdBVcO2cO9nF9XcOHRCBsWO1MWrnHV7bp0MwOOyUdvxsCPnFitBAexTrGEwGzFZIdhD1XbqjZEtCe9oxdJgPCnB09vhCUjPvW0sZOyladUuwZKym1HekRarKIdyJH6FHokPwz7HKP4VlRZrF0lfIWIh6ILhPF0obotOfKsB1bhk0UeI8qVdrAUQd4Ii53oBr9APv0UsXIVrDjovIQvD4TsME3UrxC/x7BFt9mcEKJ/ojvjWg8CuIOQotC1x0FzyiKnF6rIS9ZDCCOP5CwjYPOGsfu5yvuekwk3NHwTMI9A0spkgSW0g0JPMrjQ5eG5PGh60i64oYR1emZhUexy9nLWR0Pp50eBNgKKifwVHP77IN0RSy5MWd54VJ4EnqRXgkUepHCltWCgD17bY+682i44VGwp01Nw0evm7kAnmkpGJjdIdBXXDW9ufrIl2dZ+D/mWciktAeCRQAAAABJRU5ErkJggg==' /></div>`;");
    mainWindow.webContents.executeJavaScript("if (document.querySelector('#WINDOW_OPTIONS_CLOSE').dataset.warn == 'true') { document.querySelector('#WINDOW_OPTIONS_CLOSE').onclick = function(e) { e.preventDefault(); console.log('#Electron:dialog_box [Are%20you%20sure%20you%20want%20to%20leave?]'); } }");
  });
  require("child_process").exec("cat ./if", (e, result, i) => {
    const resultParsed = result.trim().toString().split("\n");
    for (let i = 0; i < resultParsed.length; i++) {
      if (resultParsed[i] == "wizard_conf") {
        return;
      }
    }
    require("child_process").exec("printf \"wizard_conf\" >> ./if");
    mainWindow.webContents.executeJavaScript("simple.alert('Hello! If this is your first time here, you can discover things about Parking Master 2.0, or click the \"Help\" tab all the way to the right. Enjoy!');");
  });
  process.on("uncaughtException", (err) => {});
  const req = https.request({ hostname: 'parkingmaster.tk', port: 443, path: '/update.json', method: 'GET'}, (res) => {
    var data = "";
    res.on('data', function(chunk) {
      data += chunk;
    });
    res.on('end', function() {
      data = (JSON.parse(data));
      require("child_process").exec("cat ./update.tkn", (e, result, i) => {
        if (!(result.trim() === data.updateToken.trim())) {
          (function() {
            if (data.update) {
              // Continue update
              if (data.isCritical) {
                mainWindow.webContents.executeJavaScript(`showUpdate(\`${encodeURIComponent(data.details.information)}\`)`);
                renderProcessExecutions(mainWindow, "update_proceed", (response) => {
                  if (response == "true") {
                    continueUpdateScript();
                  }
                });
              }
              function continueUpdateScript() {
                if (data.details.files.length > 0) {
                  require("child_process").exec(`printf '${data.updateToken.trim()}' > ./update.tkn`);
                  for (let i = 0; i < data.details.files.length; i++) {
                    require("child_process").exec(`> ./${data.details.files[i]}`);
                    require("child_process").exec(`cat >> ./${data.details.files[i]}<< EOF
                    ${decodeURIComponent(data.details.fileChanges[i])}`, (err) => console.log(err));
                  }
                }
              }
            } else {
              return;
            }
          })();
        }
      });
    });
  });
  req.on('error', (error) => {
    console.error(error);
  });
  req.end();
  mainWindow.webContents.on("did-finish-load", () => {
    mainWindow.webContents.executeJavaScript(`document.querySelector(".download-btn .nav-btn").innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M23 12c0 1.042-.154 2.045-.425 3h-2.101c.335-.94.526-1.947.526-3 0-4.962-4.037-9-9-9-1.706 0-3.296.484-4.654 1.314l1.857 2.686h-6.994l2.152-7 1.85 2.673c1.683-1.049 3.658-1.673 5.789-1.673 6.074 0 11 4.925 11 11zm-6.354 7.692c-1.357.826-2.944 1.308-4.646 1.308-4.963 0-9-4.038-9-9 0-1.053.191-2.06.525-3h-2.1c-.271.955-.425 1.958-.425 3 0 6.075 4.925 11 11 11 2.127 0 4.099-.621 5.78-1.667l1.853 2.667 2.152-6.989h-6.994l1.855 2.681zm-4.646-10.692c-1.657 0-3 1.343-3 3s1.343 3 3 3 3-1.343 3-3-1.343-3-3-3z"/></svg>'; document.querySelector(".download-btn .nav-btn").dataset.tippyContent = 'Check for updates'; document.querySelector(".download-btn").href = 'javascript:void(0)'; document.querySelector(".download-btn").onclick = function(e) { e.preventDefault(); alert('(Parking Master 2.0)\\n\\nNo updates are available.\\nYou\\'re using the latest version.'); };`);
  });
});